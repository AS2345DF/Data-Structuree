// mutiplication of a given number
#include<iostream>
using namespace std;
int main()
{
    int num;
    cout<<"Enter Number To Find Multiplication table ";
    cin>>num;
    for(int a=1;a<=10;a++)
	{
    cout<<num<<" * "<<a<<" = "<<num*a<<endl;
	 }
    return 0;

}
